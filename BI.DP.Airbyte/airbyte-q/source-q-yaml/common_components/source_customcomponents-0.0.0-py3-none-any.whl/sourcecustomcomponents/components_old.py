import re
import json
import logging
import os
import bs4
import sys
import time
import pendulum               
import xmltodict
import dpath.util
import requests
from airbyte_cdk.sources.declarative.decoders import Decoder
from airbyte_cdk.sources.declarative.decoders.json_decoder import JsonDecoder
from dataclasses import dataclass, InitVar
from datetime import datetime, timedelta , timezone
from jsonpath_ng import jsonpath, parse
from typing import Any, ClassVar, Iterable, Mapping, MutableMapping, Optional, Union, List, Dict, Tuple
from airbyte_cdk.sources.declarative.auth import DeclarativeOauth2Authenticator
from airbyte_cdk.sources.declarative.extractors.record_extractor import RecordExtractor
from airbyte_cdk.sources.declarative.extractors.dpath_extractor import DpathExtractor
from airbyte_cdk import AirbyteLogger
from airbyte_cdk.sources.declarative.incremental import DatetimeBasedCursor
from isodate import Duration
from airbyte_cdk.sources.declarative.types import Config, StreamSlice, StreamState, Record
from airbyte_cdk.sources.declarative.interpolation import InterpolatedString
from airbyte_cdk.sources.streams.http.http import HttpStream
from airbyte_cdk.sources.declarative.requesters import HttpRequester
from airbyte_cdk.sources.declarative.auth.declarative_authenticator import DeclarativeAuthenticator
from airbyte_cdk.sources.streams.http.auth import Oauth2Authenticator, BasicHttpAuthenticator, HttpAuthenticator
from airbyte_cdk.sources.declarative.interpolation.interpolated_string import InterpolatedString
from jinja2 import Template

logger = logging.getLogger('airbyte')

@dataclass      #same for(Netrefer)
class CustomRecordExtractor(DpathExtractor):
    config: Config
    def extract_records(self, response: requests.Response) -> List[Mapping[str , Any]]:
        #Check VPN connectivity
        if "IP Not Authenticated" in response.text:
            logger.error("IP Not Authenticated")
            assert False
         #Check Bad Authentication   
        if "Bad Authentication" in response.text:
            logger.error("Bad Authentication")
            assert False
        final_response=[]
        actual_response=[]
        response_body = self.decoder.decode(response)
        if len(self.field_path) == 0:
            extracted = response_body
        else:
            path = [path.eval(self.config) for path in self.field_path]
            if "*" in path:
                extracted = dpath.util.values(response_body, path)
            else:
                extracted = dpath.util.get(response_body, path, default=[])
        if isinstance(extracted, list):
            actual_response = extracted
        elif extracted:
            actual_response = [extracted]
        
        for record in actual_response:
            final_response.append({"data":record, "tracker_login_id":self.config["tracker_login_id"]})
                        
        return final_response
       
    
@dataclass    #same for (Myaffiliates,Softswiss)
class CustomDateTimeBasedCursor(DatetimeBasedCursor):
    config: Config
    parameters: InitVar[Mapping[str, Any]]
    recovery_dates: Optional[Union[InterpolatedString, str]] = None

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        super().__post_init__(self)
        self._recovery_dates = InterpolatedString.create(self.recovery_dates, parameters=parameters)

    def stream_slices(self) -> Iterable[StreamSlice]:
        end_datetime = self._select_best_end_datetime()
        start_datetime = self._calculate_earliest_possible_value(self._select_best_end_datetime())
        return self._chunk_date_range(start_datetime, end_datetime, self._step)

    def _chunk_date_range(self, start_date: datetime, end_date: datetime, step: Union[timedelta, Duration]) -> List[Mapping[str, Any]]: 
        start_field = "start_time"
        end_field = "end_time"
        dates = []

        lookback_days = int(self.config.get('loopback_days', 0))
        recoveryDates = self._recovery_dates.eval(self.config)
        is_recovery = self.config.get('is_recovery')
        if is_recovery:
            if recoveryDates:
                rdates = re.split(r',', recoveryDates)
                if rdates:
                    for d in rdates:
                        try:
                            dt = datetime.strptime(d, "%Y-%m-%d")
                        except Exception as e:
                            logger.error(e)
                        else:
                            start_date = end_date = self._format_datetime(dt)
                            dates.append({start_field: start_date, end_field: end_date})
        else:
            start_date = start_date + timedelta(days=-lookback_days)
            while start_date <= end_date:
                dates.append({start_field: self._format_datetime(start_date), end_field: self._format_datetime(start_date)})
                start_date += timedelta(days=1)
        logger.info(dates)    
        return dates

            
@dataclass
class CustomRequester_for_mexos(HttpRequester):
    config: Config
    def __hash__(self):
        return hash(tuple(self.__dict__))

    def get_request_body_json(
            self,
            *,
            stream_state: Optional[StreamState] = None,
            stream_slice: Optional[StreamSlice] = None,
            next_page_token: Optional[Mapping[str, Any]] = None,
    ) -> Optional[Mapping]:
        __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
        f = open(os.path.join(__location__, 'body.json'))
        body = json.load(f)
        body['report']['campaignId'] = self.config['campaign_id']
        body['report']['id'] = self.config['id']
        body['report']['input'][0]['sublist'][1]['value'] = stream_slice['start_time']
        body['report']['input'][0]['sublist'][2]['value'] = stream_slice['start_time']
        body['report']['input'][5]['value'] = self.config['variable']
        f.close()
        return body
    
    def get_request_headers(
        self,
        *,
        stream_state: Optional[StreamState] = None,
        stream_slice: Optional[StreamSlice] = None,
        next_page_token: Optional[Mapping[str, Any]] = None,
    ) -> Mapping[str, Any]:
        base_url = self.config.get('base_url')
        # Define the template
        template_str = """
        {% set cleaned_url = base_url | replace('https://', '') | replace('http://', '') | trim('/') %}
        {{ cleaned_url }}
        """
        # Create a template object
        template = Template(template_str)
        # Render the template with the base_url from config
        Host = template.render(base_url=base_url).strip()
        # Return the headers in the required format
        return {"host": Host}
    
@dataclass
class CustomRequester(HttpRequester):
    config: Config
    def __hash__(self):
        return hash(tuple(self.__dict__))
    
    def get_request_headers(
        self,
        *,
        stream_state: Optional[StreamState] = None,
        stream_slice: Optional[StreamSlice] = None,
        next_page_token: Optional[Mapping[str, Any]] = None,
    ) -> Mapping[str, Any]:
        base_url = self.config.get('base_url')
        # Define the template
        template_str = """
        {% set cleaned_url = base_url | replace('https://', '') | replace('http://', '') | trim('/') %}
        {{ cleaned_url }}
        """
        # Create a template object
        template = Template(template_str)
        # Render the template with the base_url from config
        Host = template.render(base_url=base_url).strip()
        # Return the headers in the required format
        return {"host": Host}    


@dataclass
class CustomAuthenticator(DeclarativeAuthenticator):
    config: Config
    parameters: InitVar[Mapping[str, Any]]
    basic_auth = None

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        self.basic_auth = BasicHttpAuthenticator(username=self.config['username'], password=self.config['password'])

    @property
    def auth_header(self) -> str:
        return "X-Auth-Token"

    @property
    def token(self) -> str:
        login_headers = self.basic_auth.get_auth_header()
        try:
            response = requests.get(self.config['base_url'] + '/rest/login', headers=login_headers)
            if response.status_code == 200:
                response_json = response.json()
                # logger.info(f'response from login url {response_json}')
                token = response_json['data']['value']
                try:
                    response = requests.put(self.config['base_url'] + '/rest/login/trackLogin', headers={"X-Auth-Token": token})
                    if response.status_code == 200:
                        # logger.info(token)
                        return token
                except:
                    return None
                
            elif response.status_code == 401 :
                logger.info(f"Could not request token, {response.status_code} UnAuthorised")
                assert False              
        except:
            assert False
            return None

@dataclass
class CustomRecordExtractor_for_xmlresponse(RecordExtractor):
    responsebody: Union[InterpolatedString, str]
    isattributes: Union[InterpolatedString, bool]
    responseheaders: Union[InterpolatedString,str]
    parameters: InitVar[Mapping[str, Any]]
    def __post_init__(self, parameters: Mapping[str, Any]):
        self._responsebody = InterpolatedString.create(self.responsebody, parameters=parameters)
        self._isattributes = InterpolatedString.create(self.isattributes, parameters=parameters)
        self._responseheaders = InterpolatedString.create(self.responseheaders, parameters = parameters)

    def extract_records(self, response: requests.Response) -> List[Mapping[str , Any]]:
        response_body = self._responsebody.eval(self.responsebody)
        flag = self._isattributes
        response_headers = self._responseheaders.eval(self.responseheaders)
        return self.xmlToJsonResponse(response.text, response_body,response_headers, flag)

    def xmlToJsonResponse(self, _xmlresponse, responsepath, headerspath, isattribute):
        data_dict = xmltodict.parse(_xmlresponse)
        #Read response body
        expression = parse(responsepath)  # '$.feedStatsResult.results.player[*]'
        match = expression.find(data_dict)
        responseList = []
        metadata_dict = {}
        for i in range(len(match)):
            if(isattribute == False or headerspath.strip() == True):
                # Read response Headers
                response_header = {}
                exp = parse(headerspath)
                _match = exp.find(data_dict)
                for i in range(len(_match)):
                    response_header = _match[i].value
                response_body = {"row": match[i].value}
                responseList.append(response_header | response_body)
            elif(isattribute):
                _dict = match[i].value
                for key, value in _dict.items():
                    metadata_dict[key.replace('@', '')] = value
                responseList.append(metadata_dict)
            else:
                logger.info("empty records")
                return []
                
        return responseList

@dataclass
class CustomRecordExtractor_for_mexos(DpathExtractor):
    config:Config
    def extract_records(self, response: requests.Response) -> List[Record]:
        response_body = self.decoder.decode(response)
        if 'hasData' in response_body:
            if response_body['hasData']:
                data_headers = response_body['data']['headerTitles']
                data_values = response_body['data']['values']
                finalrecord=[]
                for value in data_values:
                    row = {}
                    record = {}
                    row_data = value['data']
                    for i in range(len(row_data)):
                        row[data_headers[i]] = row_data[i]   
                    finalrecord.append(row)              
                    
                final_response=[]
                actual_response=[]
                if len(self.field_path) == 0:
                    extracted = finalrecord
                else:
                    path = [path.eval(self.config) for path in self.field_path]
                    if "*" in path:
                        extracted = dpath.util.values(finalrecord, path)
                    else:
                        extracted = dpath.util.get(finalrecord, path, default=[])
                if isinstance(extracted, list):
                    actual_response = extracted
                elif extracted:
                    actual_response = [extracted]
                
                for record in actual_response:
                    final_response.append({"data":record,"tracker_login_id":self.config["tracker_login_id"]})
                
                return final_response       
        return []


#########################################Myaffiliates

@dataclass
class CustomAuthenticator_for_Myaffiliates(DeclarativeOauth2Authenticator):    #different
    config: Config
    parameters: InitVar[Mapping[str, Any]]
    token_refresh_endpoint: Union[InterpolatedString, str]
    client_id: Union[InterpolatedString, str]
    client_secret: Union[InterpolatedString, str]
    oauth = None
    scopes: Union[InterpolatedString, str]
    grant_type: Union[InterpolatedString, str]
    refresh_access_token_headers: Union[Mapping[str, Any], None] = None
    refresh_access_token_authenticator: Union[HttpAuthenticator, None] = None
    _token_expiry_date = pendulum.now().subtract(days=1)
    access_token_name: Union[InterpolatedString, str]
    expires_in_name: Union[InterpolatedString, str]

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        # logger.info(f'config passed is  -> {self.config}')
        self.token_refresh_endpoint = InterpolatedString.create(self.config['base_url'] + '/oauth/access_token', parameters=parameters)
        self.access_token_name = InterpolatedString.create("access_token", parameters=parameters)
        self.expires_in_name = InterpolatedString.create("expires_in", parameters=parameters)
        self.grant_type = "client_credentials"
        self.scopes = "r_user_stats"
        self.client_id = self.config['client_id']
        self.client_secret = self.config['client_secret']
        self.oauth = Oauth2Authenticator(client_id=self.client_id, client_secret=self.client_secret,
                                         scopes="r_user_stats",
                                         refresh_token=None,
                                         token_refresh_endpoint=self.token_refresh_endpoint,
                                         refresh_access_token_authenticator=self.refresh_access_token_authenticator,
                                         refresh_access_token_headers=self.refresh_access_token_headers)

    def build_refresh_request_body(self) -> Mapping[str, Any]:
        payload: MutableMapping[str, Any] = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }
        if self.scopes:
            payload["scope"] = self.scopes
        
        if self.grant_type:
            payload["grant_type"] = self.grant_type

        return payload


@dataclass
class CustomRecordExtractor_for_Myaffiliates_xml(RecordExtractor):      #diMappingfferent
    parameters: InitVar[Mapping[str, Any]]
    config: Config
    StreamSlice = Mapping[str, Any]
    cursor_field = "date"
    def __post_init__(self, parameters: Mapping[str, Any]):
        pass

    def extract_records(self, response: requests.Response) -> List[Dict[Union[str, Any], Union[str, Any]]]:
        return self.parse_response(response)

    def _guaranteed_list(self, x):
        if not x:
            return []
        elif isinstance(x, list):
            return x
        else:
            return [x]

    def _parse_xml(self, xml_response):
        data_dict = xmltodict.parse(xml_response)
        report_tables = self._guaranteed_list(data_dict['reports']['table'])
        rows_lst = []
        # print(report_tables)
        for table in report_tables:
            # print(table)
            metas = table['meta']
            colDefs = table['colDefs']['col']
            rows = self._guaranteed_list(table['cellsRegion'][0]['row'])
            metadata_dict = {}
            colDefs_lst = []
            metadata_dict['plan_id'] = table['@planId']
            metadata_dict['subscription'] = table['@subscription']
            metadata_dict['customer_group'] = table['@customer_group']
            metadata_dict['caption'] = table['caption']
            for meta in metas:
                if '#text' in meta:
                    metadata_dict[meta['@name']] = meta['#text']
                else:
                    metadata_dict[meta['@name']] = ''
            for col in colDefs:
                colDefs_lst.append(col['def']['#text'])
            for row in rows:
                row_json = {}
                cells = row['cell']
                for i in range(len(cells)):
                    cell = cells[i]
                    row_json[colDefs_lst[i]] = cell['@value']
                rows_lst.append(row_json | metadata_dict)
        return rows_lst


    def parse_response(
            self,
            response: requests.Response,
            stream_state: Mapping[str, Any] = None,
            stream_slice: Mapping[str, Any] = None,
            next_page_token: Mapping[str, Any] = None,
    ) -> List[Dict[Union[str, Any], Union[str, Any]]]:
        # The response is a simple JSON whose schema matches our stream's schema exactly,
        # so we just return a list containing the response
        # if response.status_code == 200:
        # print(response.text)
        if '<html' not in response.text:
            if 'table' in response.text:
                data = self._parse_xml(response.text)
                # logger.info(f"tracker_login_id {self.config['tracker_login_id']}")
                final_record = []
                for record in data:
                    record['tracker_login_id'] = self.config["tracker_login_id"]
                    # .strftime('%Y-%m-%d')
                    final_record.append(record)
                return final_record
            else:
                logger.warning(f"Response not in html format for slice data")
                return []
        else:
            logger.warning(f"Response not in html format for slice data")
            return []
            
            
            
#######################################################Buffalo#####




@dataclass
class CustomRecordExtractor_for_Buffalopartner(RecordExtractor):        #diff
    jsonpath: Union[InterpolatedString, str]
    isattributes: Union[InterpolatedString, bool]
    parameters: InitVar[Mapping[str, Any]]
    config: Config

    def __post_init__(self, parameters: Mapping[str, Any]):
        self._jsonpath = InterpolatedString.create(self.jsonpath, parameters=parameters)
        self._isattributes = InterpolatedString.create(self.isattributes, parameters=parameters)

    def extract_records(self, response: requests.Response) -> List[Mapping[str, Any]]:
        # response_body = self.decoder.decode(response)
        json_string = self._jsonpath.eval(self.jsonpath)
        flag = self._isattributes
        logger.info(json_string)

        # logger.info(f'##########{self.xmlToJsonResponse(response ,response.text, json_string,"", flag)}')
        # response = self.xmlToJsonResponse(response ,response.text, json_string,"", flag)
        # logger.info(response_body)
        
        return self.xmlToJsonResponse(response ,response.text, json_string,"", flag)
        

    
    def xmlToJsonResponse(self, response ,_xmlresponse, responsepath, headerspath, isattribute):
        
        logger.info(response.status_code)
        logger.info('xmlToJsonResponse')
        try:
            # response = requests.get(base_url + '/api/feed/revshare/player', params = request_params)
            if response.status_code == 200:   
                if 'feedStatsResult' in response.text:
                    if 'results' in response.text:
                        data_dict = xmltodict.parse(_xmlresponse)
                        #Read response body
                        expression = parse(responsepath)  # '$.feedStatsResult.results.player[*]'
                        match = expression.find(data_dict)
                        responseList = []
                        metadata_dict = {}
                        logger.info(len(match))
                        for i in range(len(match)):
                            if(isattribute == False or headerspath.strip() == True):
                                # Read response Headers
                                response_header = {}
                                response_body = {}
                                exp = parse(headerspath)
                                _match = exp.find(data_dict)
                                for j in range(len(_match)):
                                    response_header = _match[j].value
                                response_body = {"row": match[i].value}
                                
                                responseList.append(response_header | response_body)
                            elif(isattribute):
                                _dict = match[i].value
                                for key, value in _dict.items():
                                    metadata_dict[key.replace('@', '')] = value
                                responseList.append(metadata_dict)
                            else:
                                pass
                        final_response = []
                        for record in responseList:
                            final_response.append({"data": record,"tracker_login_id": self.config.get('tracker_login_id')})
                        return final_response  
                    else:
                        logger.error(f"Logging fail")
                        sys.exit()
                        # AirbyteLogger().log("ERROR", f"Logging fail")
                        return False,None
                else:
                    if "XmlFeedError" in _xmlresponse:
                        error_message_start_index = _xmlresponse.find("<ErrorMessage>")
                        error_message_end_index = _xmlresponse.find("</ErrorMessage>")
                        error_message = _xmlresponse[error_message_start_index + len("<ErrorMessage>") : error_message_end_index]
                        logging.error("Error: %s", error_message)
                        sys.exit()
                    else:    
                        logger.error(f"Logging fail")
                        sys.exit()
                    # AirbyteLogger().log("ERROR", f"Logging fail")
                    return False,None
            else:
                logger.error(f"Logging fail")
                sys.exit()
                # AirbyteLogger().log("ERROR", f"Logging fail")
                return False,None
        except Exception as e:
            logger.error(f"Logging fail {e}")  
            # AirbyteLogger().log("ERROR", f"Logging fail: Send request got error {e}")
            return False,None
  
    


@dataclass                                       
class CustomAuthenticator_for_Buffalopartner(DeclarativeAuthenticator):      #diff
    config: Config
    parameters: InitVar[Mapping[str, Any]]

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        logger.info(f'Config passed is  ->   {self.config}')

    @property
    def auth_header(self) -> str:
        return "Authorization"

    @property
    def token(self) -> str:
        return ""

class CustomDateTimeBasedCursor_for_Buffalo_and_IncomeAccess(DatetimeBasedCursor):   #diff but same as IncAcc

    def stream_slices(self,cursor_field: List[str] = None, stream_state: Mapping[str, Any] = None) -> Iterable[StreamSlice]:
        end_datetime = self._select_best_end_datetime()
        logger.info(end_datetime)  
        start_datetime = self._calculate_earliest_possible_value(self._select_best_end_datetime())
        return self._chunk_date_range(start_datetime, end_datetime)   
    
    def _chunk_date_range(self, start_date: datetime, end_date: datetime) -> List[Mapping[str, Any]]:
        start_field = "start_time"
        end_field = "end_time"    
        dates = []
        recoveryDates = self.config.get('recovery_dates')
        is_recovery = self.config.get('is_recovery')
        loopback_days = int(self.config.get('loopback_days', 0))
        if is_recovery:
            if recoveryDates:
                rdates = re.split(r',', recoveryDates)
                if rdates:
                    for d in rdates:
                        try:
                            dt = datetime.strptime(d, "%Y-%m-%d")
                        except Exception as e:
                            logger.error(e)
                        else:
                            start_date = end_date = self._format_datetime(dt)
                            dates.append({start_field: start_date, end_field: end_date})
        else:
            start_date = start_date + timedelta(days=-loopback_days)

            while start_date < end_date:
                dates.append({start_field: self._format_datetime(start_date), end_field: self._format_datetime(start_date)})
                start_date += timedelta(days=1)
        logger.info(dates)  
        return dates        


################################################IncomeAccess

@dataclass                                            #diff(Soap env fault)
class CustomRecordExtractor_for_IncomeAccess(RecordExtractor):
    responsebody: Union[InterpolatedString, str]
    isattributes: Union[InterpolatedString, bool]
    responseheaders: Union[InterpolatedString,str]
    parameters: InitVar[Mapping[str, Any]]
    config: Config
    def __post_init__(self, parameters: Mapping[str, Any]):
        self._responsebody = InterpolatedString.create(self.responsebody, parameters=parameters)
        self._isattributes = InterpolatedString.create(self.isattributes, parameters=parameters)
        self._responseheaders = InterpolatedString.create(self.responseheaders, parameters = parameters)
        
        logger.info(self._responsebody.eval(self.responsebody))
        logger.info(self._isattributes)
        logger.info(self._responseheaders.eval(self.responseheaders))
    def extract_records(self, response: requests.Response) -> List[Mapping[str , Any]]:
        # response_body = self.decoder.decode(response)
        response_body = self._responsebody.eval(self.responsebody)
        logger.info(response_body)
        flag = self._isattributes
        response_headers = self._responseheaders.eval(self.responseheaders)
        return self.xmlToJsonResponse(response,response.text, response_body,response_headers, flag)
    
    
    def xmlToJsonResponse(self,response,_xmlresponse, responsepath, headerspath, isattribute):
        data_dict = xmltodict.parse(_xmlresponse)
        if response.status_code == 200:   
            reponse_dict = xmltodict.parse(response.text)
            logger.info(response.status_code)
            if 'SOAP-ENV:Fault' in reponse_dict['SOAP-ENV:Envelope']['SOAP-ENV:Body']:
                if reponse_dict['SOAP-ENV:Envelope']['SOAP-ENV:Body']['SOAP-ENV:Fault']['faultstring'] == 'No Records':
                    logger.info(f"Logging Success")
                    return []
                else:
                    logger.info(f"Logging fail: {reponse_dict['SOAP-ENV:Envelope']['SOAP-ENV:Body']['SOAP-ENV:Fault']['faultstring']}")
                    sys.exit()
            else:
                logger.info(f"Logging Success")
                expression = parse(responsepath)  # '$.feedStatsResult.results.player[*]'
                match = expression.find(data_dict)
                responseList = []
                metadata_dict = {}
                logger.info(len(match))
                for i in range(len(match)):
                    if(isattribute == False or headerspath.strip() == True):
                        # Read response Headers
                        response_header = {}
                        response_body = {}
                        exp = parse(headerspath)
                        _match = exp.find(data_dict)
                        for j in range(len(_match)):
                            response_header = _match[j].value
                        response_body = {"row": match[i].value}
                        
                        responseList.append(response_header | response_body)

                    elif(isattribute):
                        _dict = match[i].value
                        for key, value in _dict.items():
                            metadata_dict[key.replace('@', '')] = value
                        responseList.append(metadata_dict)
                    else:
                        pass
                #     final_response = []
                # for record in responseList:
                #     final_response.append({"data": record,"tracker_login_id": self.config.get('tracker_login_id')})
                return responseList    
        else:
            logger.info(f"Logging fail: {response.text}")
            sys.exit()

 #diff condition but same as buff-p DTBC


###########################################Q



@dataclass
class CustomRecordExtractor_for_Q(DpathExtractor):    #diff
    
    def extract_records(self, response: requests.Response) -> List[Mapping[str , Any]]:
        final_response=[]
        actual_response=[]
        response_body = self.decoder.decode(response)
        #print(response.status_code)
        x=0
        try:
            if response.status_code == 200:
                
                #print(response_body)
                if isinstance(response_body,dict):
                    if 'status' in response_body:
                        if response_body['status'] == 'Permission denied':
                            
                            AirbyteLogger().log("ERROR", f"Could not authenticate, wrong token!!!")
                            
                            
                           
                        elif response_body['status'] == 'Invalid date range':
                            AirbyteLogger().log("ERROR", f"Could authenticate but wrong date range input!!!")
                            
                            
                        else:
                            AirbyteLogger().log("INFO", f"Authenticate succeeded")
                            x=1
                    elif response.text =='[]':
                        AirbyteLogger().log("INFO", f"Authenticate succeeded")
                        x=1
                    else:
                        AirbyteLogger().log("INFO", f"Authenticate succeeded")
                        x=1
                else:
                    AirbyteLogger().log("INFO", f"Authenticate succeeded!!! list of records!!!")
                    x=1
            else:
                AirbyteLogger().log("ERROR", f"Could not request authenticate cookies")
                
                
        except:
            AirbyteLogger().log("ERROR", f"Could not authenticate, please check base_url and token")
            
      
      
        if x==1:


            if len(self.field_path) == 0:
                extracted = response_body
            else:
                path = [path.eval(self.config) for path in self.field_path]
                if "*" in path:
                    extracted = dpath.util.values(response_body, path)
                else:
                    extracted = dpath.util.get(response_body, path, default=[])
            if isinstance(extracted, list):
                actual_response = extracted
            elif extracted:
                actual_response = [extracted]
            
            for record in actual_response:
                final_response.append({"data":record})
            
            return final_response
        else:
            sys.exit()
        



class CustomDateTimeBasedCursor_for_Q(DatetimeBasedCursor):    #diff
    config: Config
    parameters: InitVar[Mapping[str, Any]]
    recovery_dates: Optional[Union[InterpolatedString, str]] = None
    cursor_field = "end"

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        super().__post_init__(self)
        self._recovery_dates = InterpolatedString.create(self.recovery_dates, parameters=parameters)
        
    def stream_slices(self) -> Iterable[StreamSlice]:
        end_datetime = self._select_best_end_datetime()
        start_datetime = self._calculate_earliest_possible_value(self._select_best_end_datetime())
        return self._chunk_date_range(start_datetime, end_datetime, self._step)
 
 
    def _chunk_date_range(self, start_date: datetime, end_date: datetime, step: Union[timedelta, Duration]) -> List[Mapping[str, Any]]: 
        start_field = "start_time"
        end_field = "end_time"
        slices = []
        dates = []
        merchants = self.config.get("merchant").split(",")
        logger.info(merchants) 
        loopback_days = int(self.config.get('loopback_days', 0))
        recoveryDates = self.config.get('recovery_dates')
        is_recovery = self.config.get('is_recovery')
        print("is recorey true or not",is_recovery)
        if is_recovery:
            if recoveryDates:
                rdates = re.split(r',', recoveryDates)
                if rdates:
                    for d in rdates:
                        try:
                            dt = datetime.strptime(d, "%Y-%m-%d")
                        except Exception as e:
                            logger.error(e)
                        else:
                            start_date = self._format_datetime(dt)
                            #end_date = self._format_datetime(dt + timedelta(days=1))
                            dates.append(start_date)
            #checking logic sample code
            for merchantid in merchants:
                for start_date in dates:
                    start_date = datetime.strptime(start_date, "%Y-%m-%d")
                    
                    
                    formatted_date = start_date.strftime("%Y-%m-%d")
                    print(formatted_date)  
                    end_date=start_date
                    slices.append({'start': formatted_date,'end':formatted_date,'merchant':merchantid})            


        else:

                date_now = str(datetime.now())
                given_date = datetime.strptime(date_now, "%Y-%m-%d %H:%M:%S.%f")
                converted_date = given_date.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=timezone.utc)
                start_date=start_date.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=timezone.utc)
                print("start date is ",type(start_date))
                print("converted date is",type(given_date))
                print("start date",start_date)
                
            
                start_date = start_date + timedelta(days=-loopback_days)
                print(start_date)
                while start_date < converted_date:
                    dates.append(start_date)
                    start_date += timedelta(days=30)
                    
                for merchantid in merchants:
                    for start_date in dates:
                        if start_date + timedelta(days=30) > converted_date:
                            end_date = converted_date
                        else:
                            end_date = start_date + timedelta(days=30)
                        end_date = end_date - timedelta(days=1)

                        
                        slices.append({'start': start_date.strftime('%Y-%m-%d'),'end':end_date.strftime('%Y-%m-%d'),'merchant':merchantid})
                        print("slices ")
                        print(slices)

                
        logger.info(slices)   
        return slices        



        
        
########################################################Smartico


@dataclass
class CustomRecordExtractor_for_Smartico(DpathExtractor):      #diff
    config: Config
    def extract_records(self, response: requests.Response) -> List[Mapping[str , Any]]:
        #Check VPN connectivity
        if "IP Not Authenticated" in response.text:
            logger.error("IP Not Authenticated")
            assert False
         #Check Bad Authentication   
        if "Bad Authentication" in response.text:
            logger.error("Bad Authentication")
            assert False
        if response.status_code != 200:
            print(response.status_code)
            print(response.text)

            logger.error("Could not authenticate")
            sys.exit()
            assert False

        final_response=[]
        actual_response=[]
        response_body = self.decoder.decode(response)
        if len(self.field_path) == 0:
            extracted = response_body
        else:
            path = [path.eval(self.config) for path in self.field_path]
            if "*" in path:
                extracted = dpath.util.values(response_body, path)
            else:
                extracted = dpath.util.get(response_body, path, default=[])
        if isinstance(extracted, list):
            actual_response = extracted
        elif extracted:
            actual_response = [extracted]
        
        for record in actual_response:
            if 'id' in record:
                del record['id']
            final_response.append({"data":record, "tracker_login_id":self.config["tracker_login_id"]})
                        
        return final_response

@dataclass
class CustomDateTimeBasedCursor_for_Smartico(DatetimeBasedCursor):   #diff
    config: Config
    parameters: InitVar[Mapping[str, Any]]
    recovery_dates: Optional[Union[InterpolatedString, str]] = None

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        super().__post_init__(self)
        self._recovery_dates = InterpolatedString.create(self.recovery_dates, parameters=parameters)

    def stream_slices(self) -> Iterable[StreamSlice]:
        end_datetime = self._select_best_end_datetime()
        start_datetime = self._calculate_earliest_possible_value(self._select_best_end_datetime())
        return self._chunk_date_range(start_datetime, end_datetime, self._step)

    def _chunk_date_range(self, start_date: datetime, end_date: datetime, step: Union[timedelta, Duration]) -> List[Mapping[str, Any]]: 
        start_field = "start_time"
        end_field = "end_time"
        dates = []
        loopback_days = int(self.config.get('loopback_days', 0))
        recoveryDates = self.config.get('recovery_dates')
        is_recovery = self.config.get('is_recovery')
        if is_recovery:
            if recoveryDates:
                rdates = re.split(r',', recoveryDates)
                if rdates:
                    for d in rdates:
                        try:
                            dt = datetime.strptime(d, "%Y-%m-%d")
                        except Exception as e:
                            logger.error(e)
                        else:
                            start_date = self._format_datetime(dt)
                            end_date = self._format_datetime(dt + timedelta(days=1))
                            dates.append({start_field: start_date, end_field: end_date})
        else:
            date_now = str(datetime.now())
            given_date = datetime.strptime(date_now, "%Y-%m-%d %H:%M:%S.%f")
            converted_date = given_date.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=timezone.utc)
            start_date = start_date + timedelta(days=-loopback_days)
            while start_date <= converted_date:
                dates.append({'start_time': start_date.strftime('%Y-%m-%d'),'end_time':(start_date + timedelta(days=1)).strftime('%Y-%m-%d')})
                start_date += timedelta(days=1)
        logger.info(dates)  
        return dates
    


##############################netrefer
#same Cust_rec

    
@dataclass
class CustomDateTimeBasedCursor_for_Netrefer(DatetimeBasedCursor):    #diff
    config: Config
    parameters: InitVar[Mapping[str, Any]]
    recovery_dates: Optional[Union[InterpolatedString, str]] = None

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        super().__post_init__(self)
        self._recovery_dates = InterpolatedString.create(self.recovery_dates, parameters=parameters)

    def stream_slices(self) -> Iterable[StreamSlice]:
        end_datetime = self._select_best_end_datetime()
        start_datetime = self._calculate_earliest_possible_value(self._select_best_end_datetime())
        return self._chunk_date_range(start_datetime, end_datetime, self._step)
    
    def _chunk_date_range(self, start_date: datetime, end_date: datetime, step: Union[timedelta, Duration]) -> List[Mapping[str, Any]]:
        start_field = "start_time"
        end_field = "end_time"
        dates = []
        loopback_days = int(self.config.get('loopback_days', 0))
        recoveryDates = self.config.get('recovery_dates')
        is_recovery = self.config.get('is_recovery')
        if is_recovery:
            if recoveryDates:
                rdates = re.split(r',', recoveryDates)
                if rdates:
                    for d in rdates:
                        try:
                            dt = datetime.strptime(d, "%Y-%m-%d")
                        except Exception as e:
                            logger.error(e)
                        else:
                            start_date = end_date = self._format_datetime(dt)
                            dates.append({start_field: start_date, end_field: end_date})
        else:
            date_now = str(datetime.now())
            given_date = datetime.strptime(date_now, "%Y-%m-%d %H:%M:%S.%f")
            converted_date = given_date.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=timezone.utc)
            start_date = start_date + timedelta(days=-loopback_days)
            while start_date < converted_date:
                dates.append({'start_time': start_date.strftime('%Y-%m-%d'),'end_time': start_date.strftime('%Y-%m-%d')})
                start_date += timedelta(days=1)
        logger.info(dates)  
        return dates


#######################################Ego

def _parse_html(html_text: str):
    records = []
    soup = bs4.BeautifulSoup(html_text, 'html.parser')
    table = soup.find('table', id='reptable')
    if table:
        theaders = table.findChild('thead').find_all('th')
        trows = table.findChild('tbody').find_all('tr')

        for row in trows:
            record = {}
            cells = row.findChildren('td')
            for i in range(0, len(cells)):
                record[theaders[i].get_text()] = cells[i].get_text()
            records.append(record)

    return records


@dataclass
class CustomRecordExtractor_for_Ego(RecordExtractor):
    def extract_records(self, response: requests.Response) -> List[Mapping[str, Any]]:
        data = []
        if response.status_code == 200:
            records = _parse_html(response.text)
            if len(records) > 0:
                for record in records:
                    record_raw = {'data': record}
                    data.append(record_raw)

        return data


@dataclass
class CustomAuthenticator_for_Ego(DeclarativeAuthenticator):   #diff
    config: Config
    basic_auth = None

    @property
    def auth_header(self) -> str:
        return "Cookie"

    @property
    def token(self) -> str:
        token = None
        body = {
            "username": self.config["username"],
            "password": self.config["password"]
        }
        try:
            session = requests.Session()
            response = session.post(self.config["base_url"] + '/login.html', data=body)
            if response.status_code == 200:
                cookies_dict = session.cookies.get_dict()
                token = "; ".join([str(x) + "=" + str(y) for x, y in cookies_dict.items()])
        except:
            token = None
        return token


@dataclass
class CustomRequester_for_Ego(HttpRequester):      #diff

    def __hash__(self):
        return hash(tuple(self.__dict__))

    def get_request_body_data(  # type: ignore
            self,
            *,
            stream_state: Optional[StreamState] = None,
            stream_slice: Optional[StreamSlice] = None,
            next_page_token: Optional[Mapping[str, Any]] = None,
    ) -> Union[Mapping[str, Any], str]:
        body = {
            "to_date": stream_slice["start_time"],
            "from_date": stream_slice["end_time"],
            "reports_table": stream_slice["report"],
            "limit_to_affiliate_name": "",
            "limit_to_affiliate_zone_data": "",
            "sortfield": "entry_date",
            "sortorder": "asc",
            "Submit2": "",
            "show_report": 1
        }
        return body


class CustomDateTimeBasedCursor_for_Ego(DatetimeBasedCursor):    #diff
    config: Config
    parameters: InitVar[Mapping[str, Any]]
    recovery_dates: Optional[Union[InterpolatedString, str]] = None

    def __post_init__(self, parameters: Mapping[str, Any]) -> None:
        super().__post_init__(self)
        self._recovery_dates = InterpolatedString.create(self.recovery_dates, parameters=parameters)


    def stream_slices(self) -> Iterable[StreamSlice]:
        end_datetime = self._select_best_end_datetime()
        start_datetime = self._calculate_earliest_possible_value(self._select_best_end_datetime())
        return self._partition_daterange(start_datetime, end_datetime, self._step)

    def _partition_daterange(self, start: datetime, end: datetime, step: Union[timedelta, Duration]):
        start_field = "start_time"
        end_field = "end_time"
        dates = []
        loopback_days = int(self.config.get('loopback_days', 0))
        recoveryDates = self.config.get('recovery_dates')
        print(recoveryDates)
        is_recovery = self.config.get('is_recovery')
        if is_recovery:
            if recoveryDates:
                rdates = re.split(r',', recoveryDates)
                print(rdates)
                if rdates:
                    for d in rdates:
                        print(d)
                        try:
                            dt = datetime.strptime(d, "%Y-%m-%d")
                        except Exception as e:
                            logger.error(e)
                        else:
                            start_date = end_date = self._format_datetime(dt)     
                            for report in self.config["reports"].split(','):
                                dates.append({start_field: start_date, end_field: end_date, 'report': report})           
        else:
            start = start + timedelta(days=-loopback_days)
            while start <= end:
                next_start = self._evaluate_next_start_date_safely(start, step)
                end_date = self._get_date(next_start - self._cursor_granularity, end, min)
                for report in self.config["reports"].split(','):
                    dates.append({start_field: self._format_datetime(start), end_field: self._format_datetime(end_date), 'report': report})
                start = next_start
        print(dates)        
        return dates